package com.demo.smarthome.protocol;

public class Buff {
	public byte[] data = null;
	public int length = 0;
}
