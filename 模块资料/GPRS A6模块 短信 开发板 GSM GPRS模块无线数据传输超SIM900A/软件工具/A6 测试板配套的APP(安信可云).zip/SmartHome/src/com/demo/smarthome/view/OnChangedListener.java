package com.demo.smarthome.view;

public interface OnChangedListener {
	abstract void OnChanged(boolean CheckState);
}
