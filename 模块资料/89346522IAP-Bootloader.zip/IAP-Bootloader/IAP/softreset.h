#ifndef _SOFTRESET_H_
#define _SOFTRESET_H_

#include "stm32f10x.h"
#include "core_cm3.h" 


void SoftReset(void);

#endif
